const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Dashboard-CLtRuHL3.js","assets/styles-CKwKSlhy.js","assets/styles-D3gO0Gdy.css","assets/format-DUrz17vr.js","assets/GlobalSearch-DBhW9JNP.js","assets/Panel-CkgAA6cH.js","assets/CraftCalculator-BlQqEP2i.js","assets/albion-items-CgYVt7Ou.js","assets/BattleTracker-BC9_8v5_.js","assets/HighscoresPage-BnbrJo7j.js","assets/search-CZVwC2s5.js","assets/BattlePage-D2kgO3IG.js","assets/PriceHistoryChart-exgtp9EQ.js","assets/PlayerProfilePage-B8MntgkA.js","assets/LoadProgress-BPaS15Fd.js","assets/GuildPicker-DAKmADJC.js","assets/GuildConfig-urU4erTF.js","assets/GuildProfilePage-B34P6T_U.js","assets/RoleIcons-CUQm_fV4.js","assets/EscalacaoPage-DD0ASzsO.js","assets/RegearPage-Dq_SpDeA.js","assets/ManagementPage-CcaSDFkh.js","assets/docs-url-DHpjfJN6.js","assets/ClaimsPanel-CpKTKJvd.js","assets/CompanionPage-C2coVa_b.js","assets/GuildSetup-Dg8ITO6U.js"])))=>i.map(i=>d[i]);
var xs=Object.defineProperty;var Hs=(e,a,o)=>a in e?xs(e,a,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[a]=o;var ze=(e,a,o)=>Hs(e,typeof a!="symbol"?a+"":a,o);import{r as d,a as is,j as s,u as Z,b as js,S as re,d as Ue,e as Be,f as qe,g as Ge,c as Ss,R as As,L as ws}from"./styles-CKwKSlhy.js";const Es="modulepreload",Ns=function(e){return"/"+e},Me={},H=function(a,o,l){let m=Promise.resolve();if(o&&o.length>0){document.getElementsByTagName("link");const n=document.querySelector("meta[property=csp-nonce]"),r=(n==null?void 0:n.nonce)||(n==null?void 0:n.getAttribute("nonce"));m=Promise.allSettled(o.map(f=>{if(f=Ns(f),f in Me)return;Me[f]=!0;const u=f.endsWith(".css"),I=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${f}"]${I}`))return;const h=document.createElement("link");if(h.rel=u?"stylesheet":Es,u||(h.as="script"),h.crossOrigin="",h.href=f,r&&h.setAttribute("nonce",r),document.head.appendChild(h),u)return new Promise((K,de)=>{h.addEventListener("load",K),h.addEventListener("error",()=>de(new Error(`Unable to preload CSS for ${f}`)))})}))}function j(n){const r=new Event("vite:preloadError",{cancelable:!0});if(r.payload=n,window.dispatchEvent(r),!r.defaultPrevented)throw n}return m.then(n=>{for(const r of n||[])r.status==="rejected"&&j(r.reason);return a().catch(j)})};function T(e){var a;window.location.pathname+window.location.search!==e&&(history.pushState({depth:(((a=history.state)==null?void 0:a.depth)??0)+1},"",e),window.dispatchEvent(new PopStateEvent("popstate")))}function Ze(e){history.replaceState(history.state,"",e)}function Fe(){var e;((e=history.state)==null?void 0:e.depth)>0?history.back():T("/")}function $s(){const[e,a]=d.useState(()=>window.location.pathname+window.location.search);return d.useEffect(()=>{const o=()=>a(window.location.pathname+window.location.search);return window.addEventListener("popstate",o),()=>window.removeEventListener("popstate",o)},[]),e}const ks=/^\/([a-z0-9]{7})$/,Ds=/^\/(\d+(?:,\d+)*)$/;function Os(e){const[a,o]=e.split("?");if(a==="/multi"){const j=new URLSearchParams(o??"").get("ids");if(!j)return null;const n=j.split(",").map(r=>r.trim()).filter(Boolean);return n.length?{type:"raw",albionIds:n}:null}const l=a.match(Ds);if(l)return{type:"raw",albionIds:l[1].split(",")};const m=a.match(ks);return m?{type:"code",code:m[1]}:null}const Cs={am:"americas",as:"asia",eu:"europe"},Ts=/^\/(am|as|eu)\/([^/]+)$/,_s=/^\/(guild|alliance)\/([^/]+)$/;function Rs(e){const[a]=e.split("?"),o=a.match(_s);return o?{type:o[1],albionId:decodeURIComponent(o[2])}:null}function zs(e){const[a,o]=e.split("?"),l=a.match(Ts);return l?{region:Cs[l[1]],name:decodeURIComponent(l[2]),activityId:new URLSearchParams(o??"").get("activity")||void 0}:null}const Us=/^\/(?:eventos|events)\/(\d+)\/(\d+)(?:\/(?:escalacao|escalation))?$/;function Bs(e){const[a]=e.split("?"),o=a.match(Us);return o?{guildId:o[1],eventId:Number(o[2])}:null}function qs(e){const[a,o]=e.split("?");if(a!=="/regears"&&a!=="/regear")return null;const l=new URLSearchParams(o??"").get("event"),m=l?Number(l):NaN;return Number.isFinite(m)&&m>0?m:null}const Gs=/^\/regears?\/(\d+)\/(\d+)$/;function Ms(e){const[a]=e.split("?"),o=a.match(Gs);return o?{guildId:o[1],requestId:Number(o[2])}:null}let ns="";const ve=e=>{ns=e},c=()=>ns,Ha=["gold","blue","green","red","purple","teal"],W={"events.view":!1,"events.create":!1,"events.manage":!1,"comps.view":!1,"comps.create":!1,"comps.manage":!1,"nodes.view":!1,"nodes.manage":!1,"guild.admin":!1,"escalacao.manage":!1};function ja(e){return a=>{const o=a.currentTarget,l=+(o.dataset.retries??0);l<3?(o.dataset.retries=String(l+1),setTimeout(()=>{o.src=o.src},800*(l+1))):e==null||e(o)}}async function Sa(e,a=3){let o=await fetch(e);for(let l=1;l<a&&!o.ok&&o.status>=500;l++)await new Promise(m=>setTimeout(m,800*l)),o=await fetch(e);return o}let Pe=!1;const xe=new Set;function Zs(e){return xe.add(e),e(Pe),()=>{xe.delete(e)}}function He(e){if(Pe!==e){Pe=e;for(const a of xe)a(e)}}const Je={pt:{net:"Sem conexão com o servidor. Tente novamente.",server:"Erro no servidor. Tente novamente em instantes."},en:{net:"Can't reach the server. Try again.",server:"Server error. Try again in a moment."},es:{net:"Sin conexión con el servidor. Inténtalo de nuevo.",server:"Error del servidor. Inténtalo de nuevo en un momento."}};function Ve(e){const a=localStorage.getItem("lang")??"pt";return(Je[a]??Je.pt)[e]}async function i(e,a){const o=(a==null?void 0:a.body)instanceof FormData;let l;try{l=await fetch(e,{credentials:"include",...o?{}:{headers:{"Content-Type":"application/json"}},...a})}catch{throw He(!0),new Error(Ve("net"))}if(He(!1),!l.ok){let m;try{m=(await l.json()).detail}catch{}throw(!m||l.status>=500&&/internal server error/i.test(m))&&(m=l.status>=500?Ve("server"):m??l.statusText),new Error(m)}return l.status===204?void 0:await l.json()}const Aa="https://discord.com/oauth2/authorize?client_id=1518276093294153859&permissions=8&scope=bot+applications.commands";function We(e,a){const o=new FormData;return o.append("file",e),a&&(o.append("crop_x",String(a.x)),o.append("crop_y",String(a.y)),o.append("crop_w",String(a.w)),o.append("crop_h",String(a.h))),o}const k={me:()=>i("/auth/me").catch(()=>null),getCraftFocusEfficiency:()=>i("/craft/focus-efficiency"),setCraftFocusEfficiency:e=>i("/craft/focus-efficiency",{method:"PUT",body:JSON.stringify({values:e})}),myDiscordGuilds:()=>i("/auth/guilds"),selectGuild:(e,a,o)=>i("/auth/select-guild",{method:"POST",body:JSON.stringify({guild_id:e,guild_name:a,icon:o})}),switchGuild:e=>i(`/auth/switch-guild/${e}`,{method:"POST"}),mySiteGuilds:()=>i("/auth/my-site-guilds"),guildInfo:e=>i(`/auth/guild-info/${e}`),updateGuildSettings:(e,a)=>i(`/auth/guild-settings/${e}`,{method:"PATCH",body:JSON.stringify(a)}),myPermissions:()=>i("/auth/my-permissions"),getMyProfile:()=>i("/profile/me"),setProfileTheme:e=>i("/profile/theme",{method:"PUT",body:JSON.stringify({theme:e})}),uploadProfileAvatar:(e,a)=>i("/profile/avatar",{method:"POST",body:We(e,a)}),removeProfileAvatar:()=>i("/profile/avatar",{method:"DELETE"}),uploadProfileBanner:(e,a)=>i("/profile/banner",{method:"POST",body:We(e,a)}),removeProfileBanner:()=>i("/profile/banner",{method:"DELETE"}),guildDiscordRoles:e=>i(`/auth/guild-discord-roles/${e}`),guildDiscordChannels:(e,a=!1)=>i(`/auth/guild-discord-channels/${e}${a?"?voice=true":""}`),guildAllies:e=>i(`/auth/guild-allies/${e}`),updateRolePermissions:(e,a,o,l)=>i(`/auth/guild-discord-roles/${e}/${a}`,{method:"PATCH",body:JSON.stringify({role_name:o,permissions:l})}),guildCommands:e=>i(`/auth/guild-commands/${e}`),toggleGuildCommand:(e,a,o)=>i(`/auth/guild-commands/${e}/${a}`,{method:"PATCH",body:JSON.stringify({enabled:o})}),updateCommandRoles:(e,a,o)=>i(`/auth/guild-commands/${e}/${a}/roles`,{method:"PATCH",body:JSON.stringify({role_keys:o})}),getComp:e=>i(`/guilds/${c()}/comps/${e}`),listComps:()=>i(`/guilds/${c()}/comps`),createComp:e=>i(`/guilds/${c()}/comps`,{method:"POST",body:JSON.stringify(e)}),updateComp:(e,a)=>i(`/guilds/${c()}/comps/${e}`,{method:"PATCH",body:JSON.stringify(a)}),deleteComp:e=>i(`/guilds/${c()}/comps/${e}`,{method:"DELETE"}),getCompFnTypes:()=>i(`/guilds/${c()}/comps/fn-types`),putCompFnTypes:e=>i(`/guilds/${c()}/comps/fn-types`,{method:"PUT",body:JSON.stringify({fn_types:e})}),listRoles:()=>i(`/guilds/${c()}/catalog/roles`),getPrices:(e,a=1)=>i(`/guilds/${c()}/catalog/prices?items=${e.join(",")}&quality=${a}`),listWeapons:()=>i(`/guilds/${c()}/catalog/weapons`),getRole:e=>i(`/guilds/${c()}/catalog/roles/${e}`),createRole:e=>i(`/guilds/${c()}/catalog/roles`,{method:"POST",body:JSON.stringify(e)}),updateRole:(e,a)=>i(`/guilds/${c()}/catalog/roles/${e}`,{method:"PATCH",body:JSON.stringify(a)}),deleteRole:e=>i(`/guilds/${c()}/catalog/roles/${e}`,{method:"DELETE"}),weaponSpells:e=>i(`/guilds/${c()}/catalog/weapons/${e}/spells`),suggestBuild:e=>i(`/guilds/${c()}/catalog/suggest`,{method:"POST",body:JSON.stringify({target_function:e})}),suggest:(e,a,o="comp")=>i(`/guilds/${c()}/comps/${e}/suggest`,{method:"POST",body:JSON.stringify({target_function:a,scope:o})}),listEvents:()=>i(`/guilds/${c()}/events`),createEvent:e=>i(`/guilds/${c()}/events`,{method:"POST",body:JSON.stringify(e)}),releaseFunctions:(e,a,o)=>i(`/guilds/${o??c()}/events/${e}/release-functions`,{method:"POST",body:JSON.stringify({released:a})}),setEventAttendance:(e,a)=>i(`/guilds/${c()}/events/${e}/attendance`,{method:"POST",body:JSON.stringify({value:a})}),updateEvent:(e,a)=>i(`/guilds/${c()}/events/${e}`,{method:"PATCH",body:JSON.stringify(a)}),listSignups:e=>i(`/guilds/${c()}/events/${e}/signups`),getEvent:e=>i(`/guilds/${c()}/events/${e}`),escalacao:(e,a)=>i(`/guilds/${e}/events/${a}/escalacao`),assignEscalacao:(e,a,o)=>i(`/guilds/${e}/events/${a}/escalacao/assign`,{method:"POST",body:JSON.stringify(o)}),autofillEscalacao:(e,a)=>i(`/guilds/${e}/events/${a}/escalacao/autofill`,{method:"POST"}),previewAutofillEscalacao:(e,a)=>i(`/guilds/${e}/events/${a}/escalacao/autofill/preview`),undoAutofillEscalacao:(e,a,o)=>i(`/guilds/${e}/events/${a}/escalacao/autofill/undo?run_id=${encodeURIComponent(o)}`,{method:"POST"}),unassignSlot:(e,a,o)=>i(`/guilds/${e}/events/${a}/escalacao/slot/${o}`,{method:"DELETE"}),unassignUser:(e,a,o)=>i(`/guilds/${e}/events/${a}/escalacao/user/${o}`,{method:"DELETE"}),escalacaoPrices:(e,a)=>i(`/guilds/${e}/events/${a}/escalacao/prices`),transition:(e,a)=>i(`/guilds/${c()}/events/${e}/transition`,{method:"POST",body:JSON.stringify({to:a})}),setStep:(e,a,o,l)=>i(`/guilds/${c()}/events/${e}/verification/${a}`,{method:"POST",body:JSON.stringify({completed:o,data:l??null})}),claimNode:(e,a,o)=>i(`/guilds/${c()}/events/${e}/nodes/${a}/claim`,{method:"POST",body:JSON.stringify(o)}),addParticipant:(e,a)=>i(`/guilds/${c()}/events/${e}/participants`,{method:"POST",body:JSON.stringify(a)}),updateParticipant:(e,a,o)=>i(`/guilds/${c()}/events/${e}/participants/${a}`,{method:"PATCH",body:JSON.stringify(o)}),removeParticipant:(e,a)=>i(`/guilds/${c()}/events/${e}/participants/${a}`,{method:"DELETE"}),getRegearEstimate:(e,a)=>i(`/guilds/${c()}/events/${e}/participants/${a}/regear-estimate`),addDeath:(e,a)=>i(`/guilds/${c()}/events/${e}/deaths`,{method:"POST",body:JSON.stringify(a)}),updateDeath:(e,a,o)=>i(`/guilds/${c()}/events/${e}/deaths/${a}`,{method:"PATCH",body:JSON.stringify(o)}),removeDeath:(e,a)=>i(`/guilds/${c()}/events/${e}/deaths/${a}`,{method:"DELETE"}),getLoot:e=>i(`/guilds/${c()}/events/${e}/loots`),getReconcile:e=>i(`/guilds/${c()}/events/${e}/reconcile`),verifyReconcileItem:(e,a,o)=>i(`/guilds/${c()}/events/${e}/reconcile/verify`,{method:"POST",body:JSON.stringify({looted_by:a,item_id:o})}),uploadChest:(e,a,o=!0)=>i(`/guilds/${c()}/events/${e}/chest`,{method:"POST",body:JSON.stringify({snapshot_at:new Date().toISOString(),entries:a,replace:o})}),listRegear:(e,a)=>{const o=new URLSearchParams;e&&o.set("status",e),a!=null&&o.set("event_id",String(a));const l=o.toString();return i(`/guilds/${c()}/regear${l?`?${l}`:""}`)},eventRegears:e=>i(`/guilds/${c()}/events/${e}/regears`),getRegear:e=>i(`/guilds/${c()}/regear/${e}`),updateRegear:(e,a)=>i(`/guilds/${c()}/regear/${e}`,{method:"PATCH",body:JSON.stringify(a)}),removeRegear:e=>i(`/guilds/${c()}/regear/${e}`,{method:"DELETE"}),getRegearSettings:()=>i(`/guilds/${c()}/regear/settings`),setRegearSettings:e=>i(`/guilds/${c()}/regear/settings`,{method:"PUT",body:JSON.stringify(e)}),regearScreenshotUrl:e=>`/guilds/${c()}/regear/${e}/screenshot`,listLootLog:e=>i(`/guilds/${c()}/lootlog?event_id=${e}`),removeLootLog:e=>i(`/guilds/${c()}/lootlog/${e}`,{method:"DELETE"}),getLootLogSettings:()=>i(`/guilds/${c()}/lootlog/settings`),setLootLogSettings:e=>i(`/guilds/${c()}/lootlog/settings`,{method:"PUT",body:JSON.stringify(e)}),listNodeDefs:()=>i(`/guilds/${c()}/nodes/defs`),upsertNodeDef:e=>i(`/guilds/${c()}/nodes/defs`,{method:"POST",body:JSON.stringify(e)}),updateNodeDef:(e,a)=>i(`/guilds/${c()}/nodes/defs/${e}`,{method:"PATCH",body:JSON.stringify(a)}),removeNodeDef:e=>i(`/guilds/${c()}/nodes/defs/${encodeURIComponent(e)}`,{method:"DELETE"}),listNodeMaps:()=>i(`/guilds/${c()}/nodes/maps`),addNodeMap:e=>i(`/guilds/${c()}/nodes/maps`,{method:"POST",body:JSON.stringify({map_name:e})}),removeNodeMap:e=>i(`/guilds/${c()}/nodes/maps/${encodeURIComponent(e)}`,{method:"DELETE"}),nearNodes:e=>i(`/guilds/${c()}/nodes/near${e?`?ts=${encodeURIComponent(e)}`:""}`)};function Fs(){const[e,a]=d.useState(null);return d.useEffect(()=>{const o=document.createElement("div");o.className="adsbox ad-banner advertisement",o.style.cssText="position:absolute;top:-9999px;left:-9999px;width:2px;height:2px;",document.body.appendChild(o);const l=setTimeout(()=>{a(o.offsetParent===null||o.offsetHeight===0),o.remove()},200);return()=>{clearTimeout(l),o.remove()}},[]),e}const rs={leaderboard:{w:728,h:90,size:"728x90"},mediumRectangle:{w:300,h:250,size:"300x250"},largeRectangle:{w:336,h:280,size:"300x250"},skyscraper:{w:160,h:600,size:"300x250"},mobileBanner:{w:320,h:50,size:"728x90"}},Ye="(max-width: 767px)";function Js(){const[e,a]=d.useState(()=>window.matchMedia(Ye).matches);return d.useEffect(()=>{const o=window.matchMedia(Ye),l=()=>a(o.matches);return o.addEventListener("change",l),()=>o.removeEventListener("change",l)},[]),e}const Vs={"728x90":"349d923ad542f5d656d1fcfb46f22eb6","300x250":"67b53d8ceb5bbe360fbf869679d47b70"};function Ws({slot:e,variant:a}){const{w:o,h:l,size:m}=rs[a],j=d.useRef(null);return d.useEffect(()=>{const n=j.current;if(!n)return;const r=Vs[m];if(!r)return;const f=`${e}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,u=document.createElement("script");u.text=`atOptions = { 'key' : '${r}', 'format' : 'iframe', 'height' : ${l}, 'width' : ${o}, 'params' : {} };`;const I=document.createElement("script");return I.src=`https://www.highperformanceformat.com/${r}/invoke.js?z=${f}`,I.async=!0,n.appendChild(u),n.appendChild(I),()=>{n.innerHTML=""}},[e,m,o,l]),s.jsx("div",{ref:j,style:{width:o,height:l,overflow:"hidden"}})}function Ys({slot:e,variant:a,mobileVariant:o}){const l=is(),m=Fs(),n=Js()&&o?o:a,{w:r,h:f}=rs[n];return s.jsx("div",{className:"ad-slot",children:s.jsx("div",{className:"ad-box",style:{width:r,height:f},children:m===null?null:m?s.jsxs("div",{className:"ad-slot-blocked",children:[s.jsx("i",{className:"ti ti-shield-off","aria-hidden":"true"}),s.jsx("span",{children:l("adblockMessage")})]}):s.jsx(Ws,{slot:e,variant:n},e)})})}const Qe="contato@ziggs.xyz";function Qs(e){return{__html:e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/¨H2¨(.*?)¨\/H2¨/g,"<h2>$1</h2>").replace(/¨H3¨(.*?)¨\/H3¨/g,"<h3>$1</h3>").replace(/¨P¨(.*?)¨\/P¨/g,"<p>$1</p>").replace(/¨UL¨([\s\S]*?)¨\/UL¨/g,"<ul>$1</ul>").replace(/¨LI¨(.*?)¨\/LI¨/g,"<li>$1</li>").replace(/¨B¨(.*?)¨\/B¨/g,"<strong>$1</strong>").replace(/¨A¨(.*?)¨\/A¨/g,'<a href="$1">$1</a>').replace(/¨BR¨/g,"<br />").replace(/¨EMAIL¨/g,`<a href="mailto:${Qe}">${Qe}</a>`)}}function Q({title:e,updated:a,body:o}){return s.jsx("div",{className:"legal-page",children:s.jsxs("div",{className:"legal-container",children:[s.jsx("h1",{children:e}),a&&s.jsx("p",{className:"legal-updated",children:a}),s.jsx("div",{className:"legal-body",dangerouslySetInnerHTML:Qs(o)})]})})}const Ks={pt:{title:"Termos de Uso",updated:"Última atualização: 26 de julho de 2026",body:`¨H2¨1. Aceitação dos termos¨/H2¨
¨P¨Ao acessar ou usar o Ziggs (ziggs.xyz), você concorda com estes Termos de Uso. Se não concordar, não use o serviço.¨/P¨

¨H2¨2. Sobre o serviço¨/H2¨
¨P¨O Ziggs é uma plataforma independente para gerenciamento de guildas de Albion Online, oferecendo composições de batalha, eventos, rastreamento de batalhas, regear, crafting e mercado.¨/P¨
¨P¨O Ziggs ¨B¨não é afiliado, associado ou endossado¨/B¨ pela Sandbox Interactive GmbH (Albion Online) ou pela Discord Inc. Todos os nomes, marcas e conteúdos relacionados ao Albion Online pertencem à Sandbox Interactive GmbH.¨/P¨

¨H2¨3. Cadastro e acesso¨/H2¨
¨P¨O acesso ao Ziggs é feito exclusivamente através da autenticação via Discord. Ao entrar, autorizamos a leitura do seu perfil público do Discord (nome de usuário e avatar) e a lista de servidores dos quais você participa.¨/P¨
¨P¨Você é responsável por manter a segurança da sua conta Discord. O Ziggs não armazena sua senha do Discord — usamos OAuth 2.0.¨/P¨

¨H2¨4. Responsabilidades do usuário¨/H2¨
¨UL¨
¨LI¨Usar o serviço de forma lícita e em conformidade com estes Termos;¨/LI¨
¨LI¨Não tentar comprometer, sobrecarregar ou explorar falhas no serviço;¨/LI¨
¨LI¨Não usar bots, scripts ou ferramentas automatizadas para acessar o Ziggs de forma abusiva;¨/LI¨
¨LI¨Não fornecer informações falsas ao vincular seu personagem do Albion Online.¨/LI¨
¨/UL¨

¨H2¨5. Idade mínima¨/H2¨
¨P¨O Ziggs é direcionado a usuários com 13 anos ou mais. Ao usar o serviço, você afirma ter pelo menos 13 anos de idade ou estar acessando com a autorização dos pais ou responsáveis.¨/P¨

¨H2¨6. Propriedade intelectual¨/H2¨
¨P¨O código, design e conteúdo original do Ziggs são de propriedade dos seus autores. Dados de jogo (nomes de itens, jogadores, guildas, batalhas) são públicos e pertencem à Sandbox Interactive GmbH.¨/P¨

¨H2¨7. Limitação de responsabilidade¨/H2¨
¨P¨O Ziggs é fornecido "como está", sem garantias de disponibilidade, precisão ou adequação a um fim específico. Não nos responsabilizamos por perdas decorrentes do uso ou da indisponibilidade do serviço.¨/P¨

¨H2¨8. Suspensão de acesso¨/H2¨
¨P¨Podemos suspender ou encerrar o acesso de usuários que violem estes Termos, a critério exclusivo da administração.¨/P¨

¨H2¨9. Alterações dos termos¨/H2¨
¨P¨Estes Termos podem ser atualizados a qualquer momento. Alterações significativas serão comunicadas através do serviço. O uso continuado após a atualização constitui aceitação.¨/P¨

¨H2¨10. Legislação aplicável¨/H2¨
¨P¨Estes Termos são regidos pelas leis da República Federativa do Brasil. Eventuais disputas serão dirimidas no foro competente.¨/P¨

¨H2¨11. Contato¨/H2¨
¨P¨Dúvidas sobre estes Termos podem ser enviadas para ¨EMAIL¨.¨/P¨`},en:{title:"Terms of Use",updated:"Last updated: July 26, 2026",body:`¨H2¨1. Acceptance of terms¨/H2¨
¨P¨By accessing or using Ziggs (ziggs.xyz), you agree to these Terms of Use. If you do not agree, do not use the service.¨/P¨

¨H2¨2. About the service¨/H2¨
¨P¨Ziggs is an independent platform for managing Albion Online guilds, offering battle compositions, events, battle tracking, regear, crafting and market features.¨/P¨
¨P¨Ziggs is ¨B¨not affiliated, associated, or endorsed by¨/B¨ Sandbox Interactive GmbH (Albion Online) or Discord Inc. All names, trademarks, and content related to Albion Online belong to Sandbox Interactive GmbH.¨/P¨

¨H2¨3. Registration and access¨/H2¨
¨P¨Access to Ziggs is done exclusively through Discord authentication. Upon login, we request access to your public Discord profile (username and avatar) and the list of servers you belong to.¨/P¨
¨P¨You are responsible for keeping your Discord account secure. Ziggs does not store your Discord password — we use OAuth 2.0.¨/P¨

¨H2¨4. User responsibilities¨/H2¨
¨UL¨
¨LI¨Use the service lawfully and in compliance with these Terms;¨/LI¨
¨LI¨Not attempt to compromise, overload, or exploit vulnerabilities in the service;¨/LI¨
¨LI¨Not use bots, scripts, or automated tools to access Ziggs in an abusive manner;¨/LI¨
¨LI¨Not provide false information when linking your Albion Online character.¨/LI¨
¨/UL¨

¨H2¨5. Minimum age¨/H2¨
¨P¨Ziggs is intended for users aged 13 or older. By using the service, you represent that you are at least 13 years old or are accessing it with parental or guardian authorization.¨/P¨

¨H2¨6. Intellectual property¨/H2¨
¨P¨The code, design, and original content of Ziggs are owned by its authors. Game data (item names, players, guilds, battles) is public and belongs to Sandbox Interactive GmbH.¨/P¨

¨H2¨7. Limitation of liability¨/H2¨
¨P¨Ziggs is provided "as is", without warranties of availability, accuracy, or fitness for a particular purpose. We are not liable for losses arising from the use or unavailability of the service.¨/P¨

¨H2¨8. Access suspension¨/H2¨
¨P¨We may suspend or terminate access for users who violate these Terms, at the sole discretion of the administration.¨/P¨

¨H2¨9. Changes to the terms¨/H2¨
¨P¨These Terms may be updated at any time. Significant changes will be communicated through the service. Continued use after updates constitutes acceptance.¨/P¨

¨H2¨10. Governing law¨/H2¨
¨P¨These Terms are governed by the laws of the Federative Republic of Brazil. Any disputes shall be resolved in the competent courts.¨/P¨

¨H2¨11. Contact¨/H2¨
¨P¨Questions about these Terms can be sent to ¨EMAIL¨.¨/P¨`},es:{title:"Términos de Uso",updated:"Última actualización: 26 de julio de 2026",body:`¨H2¨1. Aceptación de los términos¨/H2¨
¨P¨Al acceder o usar Ziggs (ziggs.xyz), aceptas estos Términos de Uso. Si no estás de acuerdo, no uses el servicio.¨/P¨

¨H2¨2. Sobre el servicio¨/H2¨
¨P¨Ziggs es una plataforma independiente para la gestión de gremios de Albion Online, que ofrece composiciones de batalla, eventos, seguimiento de batallas, regear, crafting y mercado.¨/P¨
¨P¨Ziggs ¨B¨no está afiliado, asociado ni respaldado por¨/B¨ Sandbox Interactive GmbH (Albion Online) ni Discord Inc. Todos los nombres, marcas y contenidos relacionados con Albion Online pertenecen a Sandbox Interactive GmbH.¨/P¨

¨H2¨3. Registro y acceso¨/H2¨
¨P¨El acceso a Ziggs se realiza exclusivamente mediante autenticación con Discord. Al iniciar sesión, solicitamos acceso a tu perfil público de Discord (nombre de usuario y avatar) y la lista de servidores a los que perteneces.¨/P¨
¨P¨Eres responsable de mantener la seguridad de tu cuenta de Discord. Ziggs no almacena tu contraseña de Discord — usamos OAuth 2.0.¨/P¨

¨H2¨4. Responsabilidades del usuario¨/H2¨
¨UL¨
¨LI¨Usar el servicio de forma lícita y en cumplimiento con estos Términos;¨/LI¨
¨LI¨No intentar comprometer, sobrecargar o explotar vulnerabilidades del servicio;¨/LI¨
¨LI¨No usar bots, scripts o herramientas automatizadas para acceder a Ziggs de forma abusiva;¨/LI¨
¨LI¨No proporcionar información falsa al vincular tu personaje de Albion Online.¨/LI¨
¨/UL¨

¨H2¨5. Edad mínima¨/H2¨
¨P¨Ziggs está dirigido a usuarios de 13 años o más. Al usar el servicio, declaras tener al menos 13 años o estar accediendo con autorización de tus padres o tutores.¨/P¨

¨H2¨6. Propiedad intelectual¨/H2¨
¨P¨El código, diseño y contenido original de Ziggs son propiedad de sus autores. Los datos del juego (nombres de ítems, jugadores, gremios, batallas) son públicos y pertenecen a Sandbox Interactive GmbH.¨/P¨

¨H2¨7. Limitación de responsabilidad¨/H2¨
¨P¨Ziggs se proporciona "tal cual", sin garantías de disponibilidad, precisión o idoneidad para un propósito particular. No nos hacemos responsables de pérdidas derivadas del uso o indisponibilidad del servicio.¨/P¨

¨H2¨8. Suspensión de acceso¨/H2¨
¨P¨Podemos suspender o terminar el acceso de usuarios que violen estos Términos, a discreción exclusiva de la administración.¨/P¨

¨H2¨9. Cambios a los términos¨/H2¨
¨P¨Estos Términos pueden actualizarse en cualquier momento. Los cambios significativos se comunicarán a través del servicio. El uso continuado después de la actualización constituye aceptación.¨/P¨

¨H2¨10. Ley aplicable¨/H2¨
¨P¨Estos Términos se rigen por las leyes de la República Federativa de Brasil. Cualquier disputa se resolverá en los tribunales competentes.¨/P¨

¨H2¨11. Contacto¨/H2¨
¨P¨Las dudas sobre estos Términos pueden enviarse a ¨EMAIL¨.¨/P¨`}},Xs={pt:{title:"Política de Privacidade",updated:"Última atualização: 26 de julho de 2026",body:`¨H2¨1. Introdução¨/H2¨
¨P¨Esta Política descreve como o Ziggs (ziggs.xyz) coleta, usa e protege seus dados pessoais, em conformidade com a Lei Geral de Proteção de Dados (Lei 13.709/2018 — LGPD).¨/P¨

¨H2¨2. Dados que coletamos¨/H2¨
¨H3¨2.1 Dados de autenticação (Discord OAuth)¨/H3¨
¨UL¨
¨LI¨ID da sua conta Discord (número identificador);¨/LI¨
¨LI¨Nome de usuário e nome global do Discord;¨/LI¨
¨LI¨Avatar do Discord;¨/LI¨
¨LI¨Lista de servidores dos quais você participa (para identificar quais guildas você pode gerenciar).¨/LI¨
¨/UL¨
¨P¨¨B¨Não solicitamos nem armazenamos seu email.¨/B¨ Não pedimos acesso a suas mensagens, conexões ou outros dados do Discord.¨/P¨

¨H3¨2.2 Dados de jogo (Albion Online)¨/H3¨
¨P¨Quando você vincula seu personagem do Albion Online ao seu registro, armazenamos o nome do personagem e dados públicos obtidos da API do Albion (batalhas, kills, fama, estatísticas). Esses dados são públicos e acessíveis a qualquer pessoa através da API oficial do jogo.¨/P¨

¨H3¨2.3 Dados de uso¨/H3¨
¨P¨Coletamos automaticamente dados técnicos como endereço IP, tipo de navegador e páginas visitadas, necessários para o funcionamento e segurança do serviço.¨/P¨

¨H2¨3. Base legal¨/H2¨
¨P¨O tratamento dos seus dados se baseia em:¨/P¨
¨UL¨
¨LI¨¨B¨Consentimento¨/B¨ — ao autenticar via Discord e ao aceitar esta Política;¨/LI¨
¨LI¨¨B¨Legítimo interesse¨/B¨ — para segurança do serviço, prevenção de fraude e abuso;¨/LI¨
¨LI¨¨B¨Execução de contrato¨/B¨ — para fornecer as funcionalidades que você solicita.¨/LI¨
¨/UL¨

¨H2¨4. Como usamos seus dados¨/H2¨
¨UL¨
¨LI¨Autenticar e identificar usuários;¨/LI¨
¨LI¨Vincular personagens do Albion Online às contas;¨/LI¨
¨LI¨Exibir perfis de jogadores e guildas com dados públicos do jogo;¨/LI¨
¨LI¨Gerenciar eventos, composições e regears de guildas;¨/LI¨
¨LI¨Prevenir abuso e garantir a segurança do serviço.¨/LI¨
¨/UL¨

¨H2¨5. Compartilhamento¨/H2¨
¨P¨Não vendemos nem alugamos seus dados. Compartilhamos dados apenas nas seguintes situações:¨/P¨
¨UL¨
¨LI¨¨B¨Discord Inc.¨/B¨ — para autenticação (OAuth 2.0);¨/LI¨
¨LI¨¨B¨Sandbox Interactive GmbH (Albion Online API)¨/B¨ — para buscar dados públicos de jogo;¨/LI¨
¨LI¨¨B¨Adsterra LLC¨/B¨ — para exibição de anúncios em iframes de terceiros. Consulte nossa ¨A¨/cookies¨/A¨.¨/LI¨
¨/UL¨

¨H2¨6. Cookies¨/H2¨
¨P¨Usamos cookies de sessão (necessários para o login). Detalhes na nossa ¨A¨/cookies¨/A¨.¨/P¨

¨H2¨7. Retenção¨/H2¨
¨P¨Mantemos seus dados pelo tempo necessário para fornecer o serviço. Dados de uso são mantidos por no máximo 90 dias. Dados de conta (Discord ID, personagens vinculados) são mantidos enquanto sua conta estiver ativa e podem ser excluídos mediante solicitação.¨/P¨

¨H2¨8. Seus direitos (LGPD)¨/H2¨
¨P¨Você pode exercer os seguintes direitos a qualquer momento:¨/P¨
¨UL¨
¨LI¨Acesso aos seus dados;¨/LI¨
¨LI¨Correção de dados incorretos;¨/LI¨
¨LI¨Exclusão dos seus dados ("direito ao esquecimento");¨/LI¨
¨LI¨Portabilidade dos dados;¨/LI¨
¨LI¨Revogação do consentimento.¨/LI¨
¨/UL¨
¨P¨Para exercer qualquer direito, escreva para ¨EMAIL¨.¨/P¨

¨H2¨9. Segurança¨/H2¨
¨P¨Adotamos medidas técnicas e organizacionais para proteger seus dados, incluindo criptografia em trânsito (TLS) e tokens de sessão assinados. Nenhuma medida é infalível, mas buscamos proteger seus dados contra acesso não autorizado.¨/P¨

¨H2¨10. Menores¨/H2¨
¨P¨O Ziggs não é direcionado a menores de 13 anos. Não coletamos deliberadamente dados de menores. Se acredita que um menor forneceu dados sem autorização dos pais, contate-nos para removê-los.¨/P¨

¨H2¨11. Alterações¨/H2¨
¨P¨Esta Política pode ser atualizada a qualquer momento. Alterações significativas serão comunicadas através do serviço.¨/P¨

¨H2¨12. Contato¨/H2¨
¨P¨Para dúvidas sobre privacidade, escreva para ¨EMAIL¨.¨/P¨`},en:{title:"Privacy Policy",updated:"Last updated: July 26, 2026",body:`¨H2¨1. Introduction¨/H2¨
¨P¨This Policy describes how Ziggs (ziggs.xyz) collects, uses, and protects your personal data, in compliance with the Brazilian General Data Protection Law (Law 13.709/2018 — LGPD).¨/P¨

¨H2¨2. Data we collect¨/H2¨
¨H3¨2.1 Authentication data (Discord OAuth)¨/H3¨
¨UL¨
¨LI¨Your Discord account ID (numeric identifier);¨/LI¨
¨LI¨Discord username and global name;¨/LI¨
¨LI¨Discord avatar;¨/LI¨
¨LI¨List of servers you belong to (to identify which guilds you can manage).¨/LI¨
¨/UL¨
¨P¨¨B¨We do not request or store your email.¨/B¨ We do not request access to your messages, connections, or other Discord data.¨/P¨

¨H3¨2.2 Game data (Albion Online)¨/H3¨
¨P¨When you link your Albion Online character to your account, we store the character name and public data obtained from the Albion API (battles, kills, fame, statistics). This data is public and accessible to anyone through the game's official API.¨/P¨

¨H3¨2.3 Usage data¨/H3¨
¨P¨We automatically collect technical data such as IP address, browser type, and pages visited, necessary for the operation and security of the service.¨/P¨

¨H2¨3. Legal basis¨/H2¨
¨P¨The processing of your data is based on:¨/P¨
¨UL¨
¨LI¨¨B¨Consent¨/B¨ — when authenticating via Discord and accepting this Policy;¨/LI¨
¨LI¨¨B¨Legitimate interest¨/B¨ — for service security, fraud prevention, and abuse prevention;¨/LI¨
¨LI¨¨B¨Contract performance¨/B¨ — to provide the features you request.¨/LI¨
¨/UL¨

¨H2¨4. How we use your data¨/H2¨
¨UL¨
¨LI¨Authenticate and identify users;¨/LI¨
¨LI¨Link Albion Online characters to accounts;¨/LI¨
¨LI¨Display player and guild profiles with public game data;¨/LI¨
¨LI¨Manage guild events, compositions, and regears;¨/LI¨
¨LI¨Prevent abuse and ensure service security.¨/LI¨
¨/UL¨

¨H2¨5. Sharing¨/H2¨
¨P¨We do not sell or rent your data. We share data only in the following situations:¨/P¨
¨UL¨
¨LI¨¨B¨Discord Inc.¨/B¨ — for authentication (OAuth 2.0);¨/LI¨
¨LI¨¨B¨Sandbox Interactive GmbH (Albion Online API)¨/B¨ — to fetch public game data;¨/LI¨
¨LI¨¨B¨Adsterra LLC¨/B¨ — for ad display in third-party iframes. See our ¨A¨/cookies¨/A¨.¨/LI¨
¨/UL¨

¨H2¨6. Cookies¨/H2¨
¨P¨We use session cookies (necessary for login). Details in our ¨A¨/cookies¨/A¨.¨/P¨

¨H2¨7. Retention¨/H2¨
¨P¨We keep your data for as long as necessary to provide the service. Usage data is kept for a maximum of 90 days. Account data (Discord ID, linked characters) is kept while your account is active and can be deleted upon request.¨/P¨

¨H2¨8. Your rights (LGPD)¨/H2¨
¨P¨You may exercise the following rights at any time:¨/P¨
¨UL¨
¨LI¨Access to your data;¨/LI¨
¨LI¨Correction of inaccurate data;¨/LI¨
¨LI¨Deletion of your data ("right to be forgotten");¨/LI¨
¨LI¨Data portability;¨/LI¨
¨LI¨Withdrawal of consent.¨/LI¨
¨/UL¨
¨P¨To exercise any right, write to ¨EMAIL¨.¨/P¨

¨H2¨9. Security¨/H2¨
¨P¨We adopt technical and organizational measures to protect your data, including encryption in transit (TLS) and signed session tokens. No measure is foolproof, but we strive to protect your data against unauthorized access.¨/P¨

¨H2¨10. Minors¨/H2¨
¨P¨Ziggs is not directed at children under 13. We do not knowingly collect data from minors. If you believe a minor has provided data without parental authorization, contact us to remove it.¨/P¨

¨H2¨11. Changes¨/H2¨
¨P¨This Policy may be updated at any time. Significant changes will be communicated through the service.¨/P¨

¨H2¨12. Contact¨/H2¨
¨P¨For privacy questions, write to ¨EMAIL¨.¨/P¨`},es:{title:"Política de Privacidad",updated:"Última actualización: 26 de julio de 2026",body:`¨H2¨1. Introducción¨/H2¨
¨P¨Esta Política describe cómo Ziggs (ziggs.xyz) recopila, usa y protege sus datos personales, en cumplimiento de la Ley General de Protección de Datos de Brasil (Ley 13.709/2018 — LGPD).¨/P¨

¨H2¨2. Datos que recopilamos¨/H2¨
¨H3¨2.1 Datos de autenticación (Discord OAuth)¨/H3¨
¨UL¨
¨LI¨El ID de tu cuenta de Discord (identificador numérico);¨/LI¨
¨LI¨Nombre de usuario y nombre global de Discord;¨/LI¨
¨LI¨Avatar de Discord;¨/LI¨
¨LI¨Lista de servidores a los que perteneces (para identificar qué gremios puedes gestionar).¨/LI¨
¨/UL¨
¨P¨¨B¨No solicitamos ni almacenamos tu correo electrónico.¨/B¨ No pedimos acceso a tus mensajes, conexiones u otros datos de Discord.¨/P¨

¨H3¨2.2 Datos del juego (Albion Online)¨/H3¨
¨P¨Cuando vinculas tu personaje de Albion Online a tu cuenta, almacenamos el nombre del personaje y datos públicos obtenidos de la API de Albion (batallas, kills, fama, estadísticas). Estos datos son públicos y accesibles para cualquier persona a través de la API oficial del juego.¨/P¨

¨H3¨2.3 Datos de uso¨/H3¨
¨P¨Recopilamos automáticamente datos técnicos como dirección IP, tipo de navegador y páginas visitadas, necesarios para el funcionamiento y seguridad del servicio.¨/P¨

¨H2¨3. Base legal¨/H2¨
¨P¨El tratamiento de tus datos se basa en:¨/P¨
¨UL¨
¨LI¨¨B¨Consentimiento¨/B¨ — al autenticarte mediante Discord y aceptar esta Política;¨/LI¨
¨LI¨¨B¨Interés legítimo¨/B¨ — para la seguridad del servicio, prevención de fraude y abuso;¨/LI¨
¨LI¨¨B¨Ejecución de contrato¨/B¨ — para proporcionar las funcionalidades que solicitas.¨/LI¨
¨/UL¨

¨H2¨4. Cómo usamos tus datos¨/H2¨
¨UL¨
¨LI¨Autenticar e identificar usuarios;¨/LI¨
¨LI¨Vincular personajes de Albion Online a las cuentas;¨/LI¨
¨LI¨Mostrar perfiles de jugadores y gremios con datos públicos del juego;¨/LI¨
¨LI¨Gestionar eventos, composiciones y regears de gremios;¨/LI¨
¨LI¨Prevenir abuso y garantizar la seguridad del servicio.¨/LI¨
¨/UL¨

¨H2¨5. Compartición¨/H2¨
¨P¨No vendemos ni alquilamos tus datos. Compartimos datos solo en las siguientes situaciones:¨/P¨
¨UL¨
¨LI¨¨B¨Discord Inc.¨/B¨ — para autenticación (OAuth 2.0);¨/LI¨
¨LI¨¨B¨Sandbox Interactive GmbH (API de Albion Online)¨/B¨ — para obtener datos públicos del juego;¨/LI¨
¨LI¨¨B¨Adsterra LLC¨/B¨ — para mostrar anuncios en iframes de terceros. Consulta nuestra ¨A¨/cookies¨/A¨.¨/LI¨
¨/UL¨

¨H2¨6. Cookies¨/H2¨
¨P¨Usamos cookies de sesión (necesarias para el inicio de sesión). Detalles en nuestra ¨A¨/cookies¨/A¨.¨/P¨

¨H2¨7. Retención¨/H2¨
¨P¨Mantenemos tus datos durante el tiempo necesario para proporcionar el servicio. Los datos de uso se conservan un máximo de 90 días. Los datos de la cuenta (ID de Discord, personajes vinculados) se mantienen mientras la cuenta esté activa y pueden eliminarse previa solicitud.¨/P¨

¨H2¨8. Tus derechos (LGPD)¨/H2¨
¨P¨Puedes ejercer los siguientes derechos en cualquier momento:¨/P¨
¨UL¨
¨LI¨Acceso a tus datos;¨/LI¨
¨LI¨Corrección de datos incorrectos;¨/LI¨
¨LI¨Eliminación de tus datos ("derecho al olvido");¨/LI¨
¨LI¨Portabilidad de datos;¨/LI¨
¨LI¨Revocación del consentimiento.¨/LI¨
¨/UL¨
¨P¨Para ejercer cualquier derecho, escribe a ¨EMAIL¨.¨/P¨

¨H2¨9. Seguridad¨/H2¨
¨P¨Adoptamos medidas técnicas y organizativas para proteger tus datos, incluyendo cifrado en tránsito (TLS) y tokens de sesión firmados. Ninguna medida es infalible, pero nos esforzamos por proteger tus datos contra accesos no autorizados.¨/P¨

¨H2¨10. Menores¨/H2¨
¨P¨Ziggs no está dirigido a menores de 13 años. No recopilamos deliberadamente datos de menores. Si crees que un menor ha proporcionado datos sin autorización de los padres, contáctanos para eliminarlos.¨/P¨

¨H2¨11. Cambios¨/H2¨
¨P¨Esta Política puede actualizarse en cualquier momento. Los cambios significativos se comunicarán a través del servicio.¨/P¨

¨H2¨12. Contacto¨/H2¨
¨P¨Para dudas sobre privacidad, escribe a ¨EMAIL¨.¨/P¨`}},ea={pt:{title:"Política de Cookies",updated:"Última atualização: 26 de julho de 2026",body:`¨H2¨1. O que são cookies¨/H2¨
¨P¨Cookies são pequenos arquivos de texto armazenados no seu navegador quando você visita um site. Eles permitem que o site lembre informações sobre sua visita.¨/P¨

¨H2¨2. Cookies que usamos¨/H2¨
¨H3¨Cookies necessários¨/H3¨
¨UL¨
¨LI¨¨B¨ziggs_session¨/B¨ — cookie de sessão assinado, necessário para manter você autenticado. Sem ele, você seria deslogado a cada navegação. Não pode ser desativado.¨/LI¨
¨/UL¨

¨H3¨Anúncios de terceiros (Adsterra)¨/H3¨
¨P¨Os anúncios são exibidos em iframes de terceiro (Adsterra). Esses iframes podem definir cookies próprios do domínio do Adsterra, fora do nosso controle. A maioria desses cookies é de sessão e não persiste entre visitas.¨/P¨

¨H2¨3. Gerenciamento¨/H2¨
¨P¨Você pode gerenciar ou excluir cookies a qualquer momento nas configurações do seu navegador:¨/P¨
¨UL¨
¨LI¨¨A¨https://support.google.com/chrome/answer/95647¨/A¨ (Google Chrome);¨/LI¨
¨LI¨¨A¨https://support.mozilla.org/pt-BR/kb/limpar-cookies-dados-sites-firefox¨/A¨ (Mozilla Firefox);¨/LI¨
¨LI¨¨A¨https://support.apple.com/pt-br/guide/safari/sfri11471/mac¨/A¨ (Safari).¨/LI¨
¨/UL¨
¨H2¨4. Contato¨/H2¨
¨P¨Dúvidas sobre cookies podem ser enviadas para ¨EMAIL¨.¨/P`},en:{title:"Cookie Policy",updated:"Last updated: July 26, 2026",body:`¨H2¨1. What are cookies¨/H2¨
¨P¨Cookies are small text files stored in your browser when you visit a website. They allow the site to remember information about your visit.¨/P¨

¨H2¨2. Cookies we use¨/H2¨
¨H3¨Necessary cookies¨/H3¨
¨UL¨
¨LI¨¨B¨ziggs_session¨/B¨ — signed session cookie, necessary to keep you authenticated. Without it, you would be logged out on every navigation. Cannot be disabled.¨/LI¨
¨/UL¨

¨H3¨Third-party ads (Adsterra)¨/H3¨
¨P¨Ads are displayed in third-party iframes (Adsterra). These iframes may set their own cookies on the Adsterra domain, outside our control. Most of these cookies are session-scoped and do not persist between visits.¨/P¨

¨H2¨3. Management¨/H2¨
¨P¨You can manage or delete cookies at any time in your browser settings:¨/P¨
¨UL¨
¨LI¨¨A¨https://support.google.com/chrome/answer/95647¨/A¨ (Google Chrome);¨/LI¨
¨LI¨¨A¨https://support.mozilla.org/en-US/kb/clear-cookies-and-site-data-firefox¨/A¨ (Mozilla Firefox);¨/LI¨
¨LI¨¨A¨https://support.apple.com/guide/safari/sfri11471/mac¨/A¨ (Safari).¨/LI¨
¨/UL¨
¨H2¨4. Contact¨/H2¨
¨P¨Questions about cookies can be sent to ¨EMAIL¨.¨/P`},es:{title:"Política de Cookies",updated:"Última actualización: 26 de julio de 2026",body:`¨H2¨1. ¿Qué son las cookies?¨/H2¨
¨P¨Las cookies son pequeños archivos de texto almacenados en tu navegador cuando visitas un sitio web. Permiten que el sitio recuerde información sobre tu visita.¨/P¨

¨H2¨2. Cookies que usamos¨/H2¨
¨H3¨Cookies necesarias¨/H3¨
¨UL¨
¨LI¨¨B¨ziggs_session¨/B¨ — cookie de sesión firmado, necesario para mantener tu autenticación. Sin él, serías desconectado en cada navegación. No se puede desactivar.¨/LI¨
¨/UL¨

¨H3¨Anuncios de terceros (Adsterra)¨/H3¨
¨P¨Los anuncios se muestran en iframes de terceros (Adsterra). Estos iframes pueden establecer sus propias cookies en el dominio de Adsterra, fuera de nuestro control. La mayoría de estas cookies son de sesión y no persisten entre visitas.¨/P¨

¨H2¨3. Gestión¨/H2¨
¨P¨Puedes gestionar o eliminar cookies en cualquier momento en la configuración de tu navegador:¨/P¨
¨UL¨
¨LI¨¨A¨https://support.google.com/chrome/answer/95647¨/A¨ (Google Chrome);¨/LI¨
¨LI¨¨A¨https://support.mozilla.org/es/kb/eliminar-cookies-datos-sitios-firefox¨/A¨ (Mozilla Firefox);¨/LI¨
¨LI¨¨A¨https://support.apple.com/es/guide/safari/sfri11471/mac¨/A¨ (Safari).¨/LI¨
¨/UL¨
¨H2¨4. Contacto¨/H2¨
¨P¨Las dudas sobre cookies pueden enviarse a ¨EMAIL¨.¨/P¨¨`}},sa={pt:{title:"Sobre o Ziggs",body:`¨H2¨O que é o Ziggs¨/H2¨
¨P¨O Ziggs é uma plataforma gratuita para gerenciamento de guildas de Albion Online. Oferece ferramentas para composições de batalha, eventos, rastreamento de batalhas, regear, crafting e mercado — tudo integrado ao Discord.¨/P¨

¨H2¨Para quem¨/H2¨
¨P¨O Ziggs foi criado por jogadores de Albion Online para jogadores de Albion Online. É voltado para guildas que organizam CTAs, zvZs e querem manter o controle de presença, regear e divisão de loot de forma transparente.¨/P¨

¨H2¨Recursos¨/H2¨
¨UL¨
¨LI¨Composições de batalha (comps) com builds detalhadas;¨/LI¨
¨LI¨Eventos com inscrições, escalação e autofill;¨/LI¨
¨LI¨Rastreamento automático de batalhas e perfis de jogadores;¨/LI¨
¨LI¨Rankings de highscores (PvP, coleta, crafting);¨/LI¨
¨LI¨Regear com reconhecimento de prints;¨/LI¨
¨LI¨Divisão de loot com conciliação de loggers;¨/LI¨
¨LI¨Mercado com preços atualizados continuamente;¨/LI¨
¨LI¨Companion desktop para otimização de rota e damage meter.¨/LI¨
¨/UL¨

¨H2¨Tecnologia¨/H2¨
¨P¨O Ziggs é construído com FastAPI (backend), React + TypeScript (frontend) e Tauri + Rust (companion). O código é de autoria própria e não usa dados proprietários da Sandbox Interactive.¨/P¨

¨H2¨Créditos de dados¨/H2¨
¨P¨Os preços de mercado e a cotação de ouro são fornecidos pelo ¨A¨https://www.albion-online-data.com¨/A¨ (Albion Online Data Project), um projeto comunitário open-source que coleta dados de jogo via packet sniffing. Agradecemos à comunidade AODP por manter essa infraestrutura pública.¨/P¨

¨H2¨Contato¨/H2¨
¨P¨Para dúvidas, sugestões ou parcerias, escreva para ¨EMAIL¨.¨/P¨`},en:{title:"About Ziggs",body:`¨H2¨What is Ziggs¨/H2¨
¨P¨Ziggs is a free platform for managing Albion Online guilds. It offers tools for battle compositions, events, battle tracking, regear, crafting, and market — all integrated with Discord.¨/P¨

¨H2¨Who it's for¨/H2¨
¨P¨Ziggs was created by Albion Online players for Albion Online players. It's aimed at guilds that organize CTAs, ZvZs, and want to keep transparent control of attendance, regear, and loot split.¨/P¨

¨H2¨Features¨/H2¨
¨UL¨
¨LI¨Battle compositions (comps) with detailed builds;¨/LI¨
¨LI¨Events with signups, escalation, and autofill;¨/LI¨
¨LI¨Automatic battle tracking and player profiles;¨/LI¨
¨LI¨Highscore rankings (PvP, gathering, crafting);¨/LI¨
¨LI¨Regear with screenshot recognition;¨/LI¨
¨LI¨Loot split with logger reconciliation;¨/LI¨
¨LI¨Market with continuously updated prices;¨/LI¨
¨LI¨Desktop companion for route optimization and damage meter.¨/LI¨
¨/UL¨

¨H2¨Technology¨/H2¨
¨P¨Ziggs is built with FastAPI (backend), React + TypeScript (frontend), and Tauri + Rust (companion). The code is our own and does not use proprietary data from Sandbox Interactive.¨/P¨

¨H2¨Data credits¨/H2¨
¨P¨Market prices and gold rates are provided by the ¨A¨https://www.albion-online-data.com¨/A¨ (Albion Online Data Project), a community-driven open-source project that collects game data via packet sniffing. We thank the AODP community for maintaining this public infrastructure.¨/P¨

¨H2¨Contact¨/H2¨
¨P¨For questions, suggestions, or partnerships, write to ¨EMAIL¨.¨/P¨`},es:{title:"Sobre Ziggs",body:`¨H2¨¿Qué es Ziggs?¨/H2¨
¨P¨Ziggs es una plataforma gratuita para la gestión de gremios de Albion Online. Ofrece herramientas para composiciones de batalla, eventos, seguimiento de batallas, regear, crafting y mercado — todo integrado con Discord.¨/P¨

¨H2¨Para quién¨/H2¨
¨P¨Ziggs fue creado por jugadores de Albion Online para jugadores de Albion Online. Está dirigido a gremios que organizan CTAs, ZvZs y quieren mantener un control transparente de asistencia, regear y división de loot.¨/P¨

¨H2¨Características¨/H2¨
¨UL¨
¨LI¨Composiciones de batalla (comps) con builds detalladas;¨/LI¨
¨LI¨Eventos con inscripciones, escalación y autofill;¨/LI¨
¨LI¨Seguimiento automático de batallas y perfiles de jugadores;¨/LI¨
¨LI¨Rankings de highscores (PvP, recolección, crafting);¨/LI¨
¨LI¨Regear con reconocimiento de capturas;¨/LI¨
¨LI¨División de loot con conciliación de loggers;¨/LI¨
¨LI¨Mercado con precios actualizados continuamente;¨/LI¨
¨LI¨Companion de escritorio para optimización de ruta y damage meter.¨/LI¨
¨/UL¨

¨H2¨Tecnología¨/H2¨
¨P¨Ziggs está construido con FastAPI (backend), React + TypeScript (frontend) y Tauri + Rust (companion). El código es de autoría propia y no usa datos propietarios de Sandbox Interactive.¨/P¨

¨H2¨Créditos de datos¨/H2¨
¨P¨Los precios del mercado y la cotización de oro son proporcionados por ¨A¨https://www.albion-online-data.com¨/A¨ (Albion Online Data Project), un proyecto comunitario open-source que recopila datos del juego mediante packet sniffing. Agradecemos a la comunidad AODP por mantener esta infraestructura pública.¨/P¨

¨H2¨Contacto¨/H2¨
¨P¨Para dudas, sugerencias o colaboraciones, escribe a ¨EMAIL¨.¨/P¨`}},aa={pt:{title:"Contato",body:`¨H2¨Fale conosco¨/H2¨
¨P¨Para dúvidas, sugestões, denúncias de abuso ou questões legais, envie um email para ¨EMAIL¨.¨/P¨

¨H2¨Assuntos comuns¨/H2¨
¨UL¨
¨LI¨Dúvidas sobre uso da plataforma;¨/LI¨
¨LI¨Sugestões de novos recursos;¨/LI¨
¨LI¨Denúncias de uso abusivo ou fraude;¨/LI¨
¨LI¨Solicitações de exercício de direitos (LGPD);¨/LI¨
¨LI¨Parcerias e divulgação.¨/LI¨
¨/UL¨

¨H2¨Resposta¨/H2¨
¨P¨Respondemos em até 7 dias úteis. Para questões urgentes, indique "URGENTE" no assunto do email.¨/P¨`},en:{title:"Contact",body:`¨H2¨Get in touch¨/H2¨
¨P¨For questions, suggestions, abuse reports, or legal matters, send an email to ¨EMAIL¨.¨/P¨

¨H2¨Common topics¨/H2¨
¨UL¨
¨LI¨Questions about using the platform;¨/LI¨
¨LI¨Feature suggestions;¨/LI¨
¨LI¨Reports of abusive use or fraud;¨/LI¨
¨LI¨Requests to exercise your rights (LGPD);¨/LI¨
¨LI¨Partnerships and promotion.¨/LI¨
¨/UL¨

¨H2¨Response time¨/H2¨
¨P¨We reply within 7 business days. For urgent matters, include "URGENT" in the email subject.¨/P¨`},es:{title:"Contacto",body:`¨H2¨Contáctanos¨/H2¨
¨P¨Para dudas, sugerencias, denuncias de abuso o asuntos legales, envía un email a ¨EMAIL¨.¨/P¨

¨H2¨Temas comunes¨/H2¨
¨UL¨
¨LI¨Dudas sobre el uso de la plataforma;¨/LI¨
¨LI¨Sugerencias de nuevas funciones;¨/LI¨
¨LI¨Denuncias de uso abusivo o fraude;¨/LI¨
¨LI¨Solicitudes para ejercer tus derechos (LGPD);¨/LI¨
¨LI¨Colaboraciones y difusión.¨/LI¨
¨/UL¨

¨H2¨Tiempo de respuesta¨/H2¨
¨P¨Respondemos en un máximo de 7 días hábiles. Para asuntos urgentes, indica "URGENTE" en el asunto del email.¨/P¨`}};function oa(){const{lang:e}=Z(),a=Ks[e];return s.jsx(Q,{title:a.title,updated:a.updated,body:a.body})}function ta(){const{lang:e}=Z(),a=Xs[e];return s.jsx(Q,{title:a.title,updated:a.updated,body:a.body})}function ia(){const{lang:e}=Z(),a=ea[e];return s.jsx(Q,{title:a.title,updated:a.updated,body:a.body})}function na(){const{lang:e}=Z(),a=sa[e];return s.jsx(Q,{title:a.title,updated:"",body:a.body})}function ra(){const{lang:e}=Z(),a=aa[e];return s.jsx(Q,{title:a.title,updated:"",body:a.body})}const da=d.lazy(()=>H(()=>import("./Dashboard-CLtRuHL3.js"),__vite__mapDeps([0,1,2,3,4,5]))),ca=d.lazy(()=>H(()=>import("./CraftCalculator-BlQqEP2i.js"),__vite__mapDeps([6,1,2,7,3]))),la=d.lazy(()=>H(()=>import("./BattleTracker-BC9_8v5_.js"),__vite__mapDeps([8,1,2,3,4]))),ua=d.lazy(()=>H(()=>import("./HighscoresPage-BnbrJo7j.js"),__vite__mapDeps([9,1,2,7,3,10,4]))),Ke=d.lazy(()=>H(()=>import("./BattlePage-D2kgO3IG.js"),__vite__mapDeps([11,1,2,7,12,3,10,5]))),ma=d.lazy(()=>H(()=>import("./PlayerProfilePage-B8MntgkA.js"),__vite__mapDeps([13,1,2,3,7,5,14]))),Le=d.lazy(()=>H(()=>import("./GuildPicker-DAKmADJC.js"),__vite__mapDeps([15,1,2]))),Xe=d.lazy(()=>H(()=>import("./GuildConfig-urU4erTF.js"),__vite__mapDeps([16,1,2,7,5]))),ga=d.lazy(()=>H(()=>import("./GuildProfilePage-B34P6T_U.js"),__vite__mapDeps([17,1,2,3,18,5,14]))),es=d.lazy(()=>H(()=>import("./EscalacaoPage-DD0ASzsO.js"),__vite__mapDeps([19,1,2,7]))),Ie=d.lazy(()=>H(()=>import("./RegearPage-Dq_SpDeA.js"),__vite__mapDeps([20,1,2,7]))),Y=d.lazy(()=>H(()=>import("./ManagementPage-CcaSDFkh.js"),__vite__mapDeps([21,1,2,22]))),pa=d.lazy(()=>H(()=>import("./ClaimsPanel-CpKTKJvd.js"),__vite__mapDeps([23,1,2,7,10]))),ha=d.lazy(()=>H(()=>import("./CompanionPage-C2coVa_b.js"),__vite__mapDeps([24,1,2,5]))),fa=d.lazy(()=>H(()=>import("./GuildSetup-Dg8ITO6U.js"),__vite__mapDeps([25,1,2,16,7,5])));class ba extends d.Component{constructor(){super(...arguments);ze(this,"state",{error:null})}static getDerivedStateFromError(o){return{error:o}}componentDidCatch(o){console.error("[ErrorBoundary]",o)}render(){if(this.state.error){const o=this.state.error.message||"";if(/dynamically imported module|Loading chunk|module script failed/i.test(o)){const l=Number(sessionStorage.getItem("ziggs-chunk-reload")||0);if(Date.now()-l>3e4)return sessionStorage.setItem("ziggs-chunk-reload",String(Date.now())),location.reload(),null}return s.jsxs("div",{style:{padding:24,color:"var(--text)",maxWidth:720,margin:"0 auto"},children:[s.jsx("h2",{style:{color:"var(--gold)"},children:"⚠️ Algo quebrou ao renderizar"}),s.jsxs("pre",{style:{whiteSpace:"pre-wrap",color:"var(--muted)",fontSize:12},children:[this.state.error.message,`

`,this.state.error.stack]}),s.jsxs("div",{style:{display:"flex",gap:8},children:[s.jsx("button",{className:"btn",onClick:()=>location.reload(),children:"Recarregar página"}),s.jsx("button",{className:"btn",onClick:()=>this.setState({error:null}),children:"Tentar de novo"})]})]})}return this.props.children}}function C(e){return e.icon?`https://cdn.discordapp.com/icons/${e.id}/${e.icon}.png?size=32`:null}const ss={west:"americas",east:"asia",europe:"europe"};function ye(e){if(e<90)return"~1min";if(e<3600)return`~${Math.round(e/60)}min`;const a=e/3600;return a<10?`~${a.toFixed(1)}h`:`~${Math.round(a)}h`}function as(e){return e<900?"var(--success)":e<7200?"#e0a23b":"var(--alert)"}function os({t:e}){return s.jsx("footer",{className:"site-footer",children:s.jsxs("div",{className:"site-footer-inner",children:[s.jsxs("nav",{className:"site-footer-nav",children:[s.jsx("a",{href:"/terms",children:e("footerTerms")}),s.jsx("span",{className:"site-footer-sep",children:"·"}),s.jsx("a",{href:"/privacy",children:e("footerPrivacy")}),s.jsx("span",{className:"site-footer-sep",children:"·"}),s.jsx("a",{href:"/cookies",children:e("footerCookies")}),s.jsx("span",{className:"site-footer-sep",children:"·"}),s.jsx("a",{href:"/about",children:e("footerAbout")}),s.jsx("span",{className:"site-footer-sep",children:"·"}),s.jsx("a",{href:"/contact",children:e("footerContact")})]}),s.jsx("p",{className:"site-footer-disclaimer",children:e("footerNotAffiliated")})]})})}const va={"300x250":"67b53d8ceb5bbe360fbf869679d47b70","728x90":"349d923ad542f5d656d1fcfb46f22eb6"},ts={"300x250":[300,250],"728x90":[728,90]};function La({size:e}){const a=d.useRef(null);d.useEffect(()=>{const m=a.current;if(!m)return;const j=va[e],[n,r]=ts[e]??[300,250],f=document.createElement("script");f.text=`atOptions = { 'key' : '${j}', 'format' : 'iframe', 'height' : ${r}, 'width' : ${n}, 'params' : {} };`;const u=document.createElement("script");u.src=`https://www.highperformanceformat.com/${j}/invoke.js`,u.async=!0,m.appendChild(f),m.appendChild(u)},[e]);const[o,l]=ts[e]??[300,250];return s.jsx("div",{ref:a,style:{width:o,height:l,margin:0,padding:0,overflow:"hidden"}})}function Ia(){const{lang:e,setLang:a}=Z(),{server:o,setServer:l,servers:m,toggleServer:j}=js(),n=is(),[r,f]=d.useState(void 0),[u,I]=d.useState("dashboard"),[h,K]=d.useState(null),[de,ds]=d.useState("alltime"),[je,F]=d.useState([]),[X,ee]=d.useState(W),[Se,_]=d.useState(!1),[Ae,D]=d.useState(!1),[ce,se]=d.useState(!1),[le,we]=d.useState(!1),[Ee,cs]=d.useState({});d.useEffect(()=>{const t=()=>fetch("/meta/battle-delay").then(p=>p.ok?p.json():{}).then(cs).catch(()=>{});t();const g=setInterval(t,6e4);return()=>clearInterval(g)},[]);const[ae,A]=d.useState("main"),[oe,ls]=d.useState(null),[Ne,us]=d.useState(new Set),[ue,ms]=d.useState(null),[te,$e]=d.useState(null),ie=d.useRef(null),me=d.useRef(null),ge=d.useRef(null),y=$s(),O=Os(y),w=zs(y),R=Rs(y),P=Bs(y),v=Ms(y),E=qs(y),J=y.split("?")[0]==="/download",V=y.split("?")[0],q=V==="/terms"?"terms":V==="/privacy"?"privacy":V==="/cookies"?"cookies":V==="/about"?"about":V==="/contact"?"contact":null,ke=y.split("?")[0],De=ke==="/ad/300x250"?"300x250":ke==="/ad/728x90"?"728x90":null,Oe=y.split("?")[0]==="/highscores";d.useEffect(()=>{const t=y.split("?")[1];if(y.split("?")[0]!=="/"||!t)return;const g=new URLSearchParams(t).get("view");(g==="management"||g==="config")&&(I(g),Ze("/"))},[y]),d.useEffect(()=>{if(r!==void 0)return;let t=!1;const g=setTimeout(()=>{t||(t=!0,f(null))},8e3);return k.me().then(p=>{t||(t=!0,clearTimeout(g),f(p),p!=null&&p.guild_id&&(ve(p.guild_id),Promise.all([k.mySiteGuilds(),k.myPermissions()]).then(([L,$])=>{F(L),ee($)})))}),()=>clearTimeout(g)},[y,r]),d.useEffect(()=>{if(!Oe)return;const t=new URLSearchParams(y.split("?")[1]??""),g=t.get("kind"),p=t.get("player"),L=Number(t.get("rank")),$=t.get("regions");g&&p&&Number.isFinite(L)&&L>0&&(K({kind:g,player:p,rank:L,regions:$??""}),I("highscores")),Ze("/")},[Oe,y]),d.useEffect(()=>{u==="highscores"&&h&&K(null)},[u,h]),d.useEffect(()=>{function t(g){const p=g.target;ie.current&&!ie.current.contains(p)&&D(!1),me.current&&!me.current.contains(p)&&(se(!1),A("main")),ge.current&&!ge.current.contains(p)&&we(!1)}return document.addEventListener("mousedown",t),()=>document.removeEventListener("mousedown",t)},[]),d.useEffect(()=>{if(!ce)return;const t=()=>fetch("/meta/reprocess-progress").then(p=>p.json()).then(ls).catch(()=>{});t();const g=setInterval(t,3e3);return()=>clearInterval(g)},[ce]);const x=r!==null,pe=je.filter(t=>t.bot_present),S=pe.find(t=>t.id===(r==null?void 0:r.guild_id))??null,G=je.find(t=>t.id===(r==null?void 0:r.guild_id))??null,z=!!(r!=null&&r.guild_id)&&!!S,Ce=!!G&&(!G.bot_present||!G.albion_guild_name),gs=pe.length>1,Te=Object.values(X).some(Boolean),N=x&&z&&!Ce&&!Se&&(!P&&!v&&!E&&!O&&!w&&!R&&!J&&!q)&&(u==="management"||u==="config"),M=!!P,U=!!v||!!(E&&(r!=null&&r.guild_id)),he=v?{guildId:v.guildId,initialRequestId:v.requestId,eventId:void 0}:E&&(r!=null&&r.guild_id)?{guildId:String(r.guild_id),initialRequestId:void 0,eventId:E}:null;d.useEffect(()=>{N&&us(t=>t.has(u)?t:new Set(t).add(u))},[N,u]),d.useEffect(()=>{P&&ms({guildId:P.guildId,eventId:P.eventId})},[P==null?void 0:P.guildId,P==null?void 0:P.eventId]),d.useEffect(()=>{v?$e({guildId:v.guildId,initialRequestId:v.requestId}):E&&(r!=null&&r.guild_id)&&$e({guildId:String(r.guild_id),eventId:E})},[v==null?void 0:v.guildId,v==null?void 0:v.requestId,E,r==null?void 0:r.guild_id]),d.useEffect(()=>{let t="";J?t=n("companionNav"):O?t=n("battles"):w?t=w.name||n("players"):R||(t={battles:n("battles"),highscores:n("highscores"),craft:n("craft"),companion:n("companionNav"),management:n("management"),config:"Config"}[u]??""),document.title=t?`${t} · Ziggs`:"Ziggs — Controle de guildas de Albion"},[u,J,O,w,R,n]);const[fe,ps]=d.useState(!1);if(d.useEffect(()=>Zs(ps),[]),d.useEffect(()=>{if(!fe)return;const t=setInterval(async()=>{try{(await fetch("/health")).ok&&He(!1)}catch{}},1e4);return()=>clearInterval(t)},[fe]),r===void 0)return null;if(De)return s.jsx(La,{size:De});if(q){const t=q==="terms"?s.jsx(oa,{}):q==="privacy"?s.jsx(ta,{}):q==="cookies"?s.jsx(ia,{}):q==="about"?s.jsx(na,{}):s.jsx(ra,{});return s.jsxs("div",{className:"app-shell",children:[s.jsxs("div",{className:"dash-root",children:[s.jsx("div",{className:"legal-back-bar",children:s.jsxs("button",{className:"btn",onClick:()=>T("/"),children:[s.jsx("i",{className:"ti ti-arrow-left"})," ",n("back")]})}),t]}),s.jsx(os,{t:n})]})}async function hs(){await fetch("/auth/logout",{method:"POST",credentials:"include"}),f(null),F([]),ee(W),I("dashboard")}function be(t,g,p){ve(t),f(L=>L&&{...L,guild_id:t}),_(!1),Promise.all([k.mySiteGuilds(),k.myPermissions()]).then(([L,$])=>{F(L),ee($)}),I(p?"management":"config")}async function fs(t){D(!1);const g=await k.switchGuild(t.id);ve(t.id),f($=>$&&{...$,guild_id:t.id});const[p,L]=await Promise.all([k.mySiteGuilds(),k.myPermissions()]);F(p),ee(L),I(g.bot_present?"management":"config")}const B=(t,g,p)=>s.jsxs("button",{className:!O&&!w&&!R&&u===t?"active":"",onClick:()=>{J&&T("/"),I(t)},children:[s.jsx("i",{className:`ti ${g}`,"aria-hidden":"true"})," ",p]}),bs=m.length>1?s.jsx("div",{className:"server-quick-switch",children:m.map(t=>s.jsx("button",{className:"server-quick-btn"+(t===o?" active":""),title:Ue[t],onClick:()=>l(t),children:re[t]},t))}):null,ne=Object.entries(Ee).filter(([,t])=>t.delay_secs>15*60),vs=ne.some(([t])=>t===ss[o]),Ls=ne.length?`${n("siteInstabilityApiDelay")}: ${ne.map(([t,g])=>`${Be[e][t]??t} ${ye(g.delay_secs)}`).join(" · ")}. ${n("apiDelayHint")}`:"",Is=s.jsxs("div",{className:"topbar-dropdown",ref:me,children:[s.jsxs("button",{className:"topbar-dropdown-btn",onClick:()=>{se(t=>!t),A("main")},children:[s.jsx("i",{className:`ti ${x?"ti-user-circle":"ti-settings"}`}),s.jsx("span",{children:x?r.global_name||r.username:n("config")}),s.jsx("i",{className:"ti ti-chevron-down",style:{fontSize:10}})]}),ce&&s.jsxs("div",{className:"topbar-dropdown-menu user-menu",children:[ae==="claims"&&s.jsx(d.Suspense,{fallback:null,children:s.jsx(pa,{onBack:()=>A("main")})}),ae==="main"&&s.jsxs(s.Fragment,{children:[x&&s.jsxs(s.Fragment,{children:[s.jsxs("div",{className:"user-menu-header",children:[s.jsx("i",{className:"ti ti-user-circle",style:{fontSize:28,color:"var(--muted)"}}),s.jsx("span",{children:r.global_name||r.username})]}),s.jsx("div",{className:"user-menu-divider"}),s.jsxs("button",{className:"topbar-dropdown-item",onClick:()=>A("claims"),children:[s.jsx("i",{className:"ti ti-user-check"}),n("myCharacters"),s.jsx("i",{className:"ti ti-chevron-right",style:{fontSize:11}})]}),s.jsx("div",{className:"user-menu-divider"})]}),s.jsxs("button",{className:"topbar-dropdown-item",onClick:()=>A("lang"),children:[s.jsx("i",{className:"ti ti-language"}),n("lang"),s.jsx("span",{className:"user-menu-current",children:qe[e]}),s.jsx("i",{className:"ti ti-chevron-right",style:{fontSize:11}})]}),s.jsxs("button",{className:"topbar-dropdown-item",onClick:()=>A("server"),children:[s.jsx("i",{className:"ti ti-server-2"}),n("server"),s.jsx("span",{className:"user-menu-current",children:m.map(t=>re[t]).join(" · ")}),s.jsx("i",{className:"ti ti-chevron-right",style:{fontSize:11}})]}),s.jsx("div",{className:"user-menu-divider"}),x?s.jsxs("button",{className:"topbar-dropdown-item danger",onClick:()=>{se(!1),A("main"),hs()},children:[s.jsx("i",{className:"ti ti-logout"})," ",n("logout")]}):s.jsxs("a",{className:"topbar-dropdown-item",href:"/auth/discord/login",children:[s.jsx("i",{className:"ti ti-brand-discord"})," ",n("loginDiscord")]}),oe&&oe.pending>0&&s.jsxs(s.Fragment,{children:[s.jsx("div",{className:"user-menu-divider"}),s.jsxs("div",{className:"user-menu-progress",children:[n("reprocessProgress"),s.jsx("div",{className:"user-menu-progress-bar",children:s.jsx("div",{style:{width:`${oe.percent}%`}})}),oe.percent.toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}),"%"]})]})]}),ae==="lang"&&s.jsxs(s.Fragment,{children:[s.jsxs("button",{className:"user-menu-back",onClick:()=>A("main"),children:[s.jsx("i",{className:"ti ti-arrow-left"})," ",n("lang")]}),s.jsx("div",{className:"user-menu-divider"}),Object.keys(Ge).map(t=>s.jsxs("button",{className:"topbar-dropdown-item"+(t===e?" active":""),onClick:()=>{a(t),A("main")},children:[s.jsx("span",{className:"user-menu-abbr",children:Ge[t]}),qe[t],t===e&&s.jsx("i",{className:"ti ti-check",style:{marginLeft:"auto",fontSize:13}})]},t))]}),ae==="server"&&s.jsxs(s.Fragment,{children:[s.jsxs("button",{className:"user-menu-back",onClick:()=>A("main"),children:[s.jsx("i",{className:"ti ti-arrow-left"})," ",n("server")]}),s.jsx("div",{className:"user-menu-divider"}),Object.keys(re).map(t=>{const g=m.includes(t),p=t===o;return s.jsxs("button",{className:"topbar-dropdown-item"+(g?" active":""),onClick:()=>j(t),children:[s.jsx("i",{className:"ti "+(g?"ti-square-check-filled":"ti-square"),style:{fontSize:15}}),s.jsx("span",{className:"user-menu-abbr",children:re[t]}),Ue[t],(()=>{const L=Ee[ss[t]];return L?s.jsx("span",{style:{marginLeft:"auto",fontSize:11,color:as(L.delay_secs),fontVariantNumeric:"tabular-nums"},title:n("apiDelayHint"),children:ye(L.delay_secs)}):null})(),p&&g&&m.length>1&&s.jsx("span",{className:"user-menu-active-dot"})]},t)})]})]})]}),_e=s.jsxs("div",{className:"login-gate",children:[s.jsx("i",{className:"ti ti-lock login-gate-icon"}),s.jsx("p",{className:"login-gate-title",children:n("guildOnly")}),s.jsx("p",{className:"login-gate-sub",children:n("loginRequired")}),s.jsxs("a",{className:"btn btn-discord",href:"/auth/discord/login",children:[s.jsx("i",{className:"ti ti-brand-discord"})," ",n("loginDiscord")]})]});let b;P?b=s.jsx(es,{guildId:P.guildId,eventId:P.eventId}):v?b=s.jsx(Ie,{guildId:v.guildId,initialRequestId:v.requestId}):E&&(r!=null&&r.guild_id)?b=s.jsx(Ie,{guildId:String(r.guild_id),eventId:E}):J||u==="companion"?b=s.jsx(ha,{}):O?b=O.type==="code"?s.jsx(Ke,{code:O.code,onBack:()=>T("/")}):s.jsx(Ke,{albionIds:O.albionIds,onBack:()=>T("/")}):w?b=s.jsx(ma,{region:w.region,name:w.name,activityId:w.activityId,onBack:Fe}):R?b=s.jsx(ga,{mode:R.type,albionId:R.albionId,onBack:Fe}):Se&&x?b=u==="management"?s.jsx(Y,{perms:W,empty:s.jsx(Le,{onSelect:be})}):s.jsx(Le,{onSelect:be}):!x&&u==="management"?b=s.jsx(Y,{perms:W,empty:_e}):!x&&u==="config"?b=_e:x&&Ce&&(u==="management"||u==="config")?b=s.jsx(d.Suspense,{fallback:null,children:s.jsx(fa,{guildId:r.guild_id,guildName:G.name,botPresent:G.bot_present,hasAlbionName:!!G.albion_guild_name,onSwitch:()=>_(!0),onComplete:()=>{k.mySiteGuilds().then(t=>{F(t),I("config")})}})}):x&&u==="management"&&!z?b=s.jsx(Y,{perms:W,empty:s.jsx(Le,{onSelect:be})}):u==="dashboard"?b=s.jsx(da,{onOpenBattles:()=>{T("/"),I("battles")},onOpenHighscores:()=>{ds("week"),T("/"),I("highscores")}}):u==="battles"?b=s.jsx(la,{}):u==="highscores"?b=s.jsx(ua,{initialWindow:de,initialKind:h==null?void 0:h.kind,highlightPlayer:h==null?void 0:h.player,initialRank:h==null?void 0:h.rank,initialRegions:(h==null?void 0:h.regions)||void 0}):u==="craft"?b=s.jsx(ca,{}):u==="management"?b=s.jsx(Y,{guildId:r.guild_id,perms:X}):b=s.jsx(Xe,{guildId:r.guild_id,onSwitch:()=>_(!0)});const ys=z&&S?gs?s.jsxs("div",{className:"guild-switcher",ref:ie,children:[s.jsxs("button",{className:"guild-switcher-btn",onClick:()=>D(t=>!t),children:[C(S)&&s.jsx("img",{src:C(S),alt:"",className:"guild-switcher-icon"}),s.jsx("span",{children:S.name}),s.jsx("i",{className:"ti ti-chevron-down",style:{fontSize:11}})]}),Ae&&s.jsxs("div",{className:"guild-switcher-dropdown",children:[pe.map(t=>s.jsxs("button",{className:`guild-switcher-option${t.id===(r==null?void 0:r.guild_id)?" active":""}`,onClick:()=>fs(t),children:[C(t)?s.jsx("img",{src:C(t),alt:"",className:"guild-switcher-icon"}):s.jsx("span",{className:"guild-switcher-icon-placeholder",children:t.name[0]}),s.jsx("span",{children:t.name})]},t.id)),s.jsxs("button",{className:"guild-switcher-option guild-switcher-add",onClick:()=>{D(!1),_(!0)},children:[s.jsx("i",{className:"ti ti-plus"})," ",n("addServer")]})]})]}):s.jsxs("div",{className:"guild-switcher",ref:ie,children:[s.jsxs("button",{className:"guild-switcher-btn",onClick:()=>D(t=>!t),children:[C(S)&&s.jsx("img",{src:C(S),alt:"",className:"guild-switcher-icon"}),s.jsx("span",{children:S.name}),s.jsx("i",{className:"ti ti-chevron-down",style:{fontSize:11}})]}),Ae&&s.jsxs("div",{className:"guild-switcher-dropdown",children:[s.jsxs("button",{className:"guild-switcher-option active",onClick:()=>D(!1),children:[C(S)?s.jsx("img",{src:C(S),alt:"",className:"guild-switcher-icon"}):s.jsx("span",{className:"guild-switcher-icon-placeholder",children:S.name[0]}),s.jsx("span",{children:S.name}),s.jsx("i",{className:"ti ti-circle-check-filled",style:{color:"var(--green)",fontSize:12,marginLeft:"auto"}})]}),s.jsxs("button",{className:"guild-switcher-option guild-switcher-add",onClick:()=>{D(!1),_(!0)},children:[s.jsx("i",{className:"ti ti-plus"})," ",n("addServer")]})]})]}):x?s.jsxs("button",{className:"guild-switcher-btn",onClick:()=>_(!0),children:[s.jsx("i",{className:"ti ti-server",style:{fontSize:14}}),s.jsx("span",{children:n("selectServer")}),s.jsx("i",{className:"ti ti-chevron-down",style:{fontSize:11}})]}):s.jsxs("span",{className:"nav-guild-label",children:[s.jsx("i",{className:"ti ti-lock"})," ",n("guildLockedLabel")]}),Ps=x&&z&&X["guild.admin"],Re=!x||!z||Te;return s.jsxs("div",{className:"app-shell",children:[fe&&s.jsxs("div",{className:"backend-down-banner",role:"alert",children:[s.jsx("i",{className:"ti ti-plug-connected-x","aria-hidden":"true"})," ",n("backendDown")]}),s.jsxs("div",{className:"topbar",children:[s.jsxs("button",{className:"brand",onClick:()=>{T("/"),I("dashboard")},title:n("dashboard"),children:[s.jsx("span",{className:"logo",children:s.jsx("i",{className:"ti ti-shield-half"})}),"Ziggs"]}),s.jsxs("nav",{className:"nav nav-public",children:[B("battles","ti-shield-bolt",n("battles")),B("highscores","ti-trophy",n("highscores")),B("craft","ti-hammer",n("craft")),B("companion","ti-device-desktop",n("companionNav"))]}),s.jsx("div",{className:"nav-sep"}),Re&&s.jsxs("div",{className:`nav-guild-box${x&&z&&!Te?" locked":x?"":" locked"}`,children:[ys,s.jsxs("nav",{className:"nav",children:[B("management","ti-adjustments-alt",n("management")),Ps&&B("config","ti-settings",n("config"))]})]}),!Re&&s.jsx("nav",{className:"nav",children:B("management","ti-adjustments-alt",n("management"))}),s.jsxs("div",{style:{marginLeft:"auto",display:"flex",alignItems:"center",gap:6},children:[vs&&s.jsxs("div",{className:"topbar-status",ref:ge,children:[s.jsx("button",{type:"button",className:`topbar-instability${le?" active":""}`,onClick:()=>{we(t=>!t),se(!1),D(!1)},"aria-label":Ls,"aria-expanded":le,"aria-haspopup":"menu",children:s.jsx("i",{className:"ti ti-alert-triangle","aria-hidden":"true"})}),le&&s.jsxs("div",{className:"status-dropdown",role:"menu",children:[s.jsxs("div",{className:"status-dropdown-head",children:[s.jsx("span",{className:"status-dropdown-icon",children:s.jsx("i",{className:"ti ti-alert-triangle","aria-hidden":"true"})}),s.jsxs("span",{children:[s.jsx("strong",{children:n("systemStatus")}),s.jsx("small",{children:n("systemStatusDegraded")})]})]}),s.jsx("div",{className:"status-dropdown-list",children:ne.map(([t,g])=>s.jsxs("div",{className:"status-dropdown-row",children:[s.jsx("span",{className:"status-pulse"}),s.jsxs("span",{className:"status-region",children:[s.jsx("strong",{children:Be[e][t]??t}),s.jsx("small",{children:n("apiPublishingDelay")})]}),s.jsx("span",{className:"status-delay",style:{color:as(g.delay_secs)},children:ye(g.delay_secs)})]},t))}),s.jsx("p",{className:"status-dropdown-note",children:n("apiDelayHint")})]})]}),bs,Is]})]}),s.jsxs("div",{className:"dash-root",children:[u!=="craft"&&s.jsx("div",{style:{padding:"10px 16px 0"},children:s.jsx(Ys,{slot:`top-${u}`,variant:"leaderboard",mobileVariant:"mobileBanner"},`top-${u}`)}),s.jsx(ba,{children:s.jsxs(d.Suspense,{fallback:s.jsx("div",{style:{display:"flex",justifyContent:"center",padding:48},children:s.jsx("i",{className:"ti ti-loader-2 spin",style:{fontSize:22,color:"var(--muted)"},"aria-hidden":"true"})}),children:[!N&&!M&&!U&&b,x&&z&&s.jsxs(s.Fragment,{children:[(N&&u==="management"||Ne.has("management"))&&s.jsx("div",{style:N&&u==="management"?void 0:{display:"none"},children:s.jsx(Y,{guildId:r.guild_id,perms:X,active:N&&u==="management"})}),(N&&u==="config"||Ne.has("config"))&&s.jsx("div",{style:N&&u==="config"?void 0:{display:"none"},children:s.jsx(Xe,{guildId:r.guild_id,onSwitch:()=>_(!0),active:N&&u==="config"})})]}),(M||ue)&&s.jsx("div",{style:M?void 0:{display:"none"},children:s.jsx(es,{guildId:M?P.guildId:ue.guildId,eventId:M?P.eventId:ue.eventId,active:M})}),(U||te)&&s.jsx("div",{style:U?void 0:{display:"none"},children:s.jsx(Ie,{guildId:U?he.guildId:te.guildId,initialRequestId:U?he.initialRequestId:te.initialRequestId,eventId:U?he.eventId:te.eventId,active:U})})]})})]}),s.jsx(os,{t:n})]})}Ss.createRoot(document.getElementById("root")).render(s.jsx(As.StrictMode,{children:s.jsx(ws,{children:s.jsx(Ia,{})})}));export{Ys as A,Aa as B,Ha as P,H as _,k as a,Ze as b,Sa as f,c as g,ja as i,T as n,ve as s};
