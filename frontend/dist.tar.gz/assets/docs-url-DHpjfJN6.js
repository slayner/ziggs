const s="/docs.html",o="/";export{s as D,o as S};
